import React from 'react';
import { Check } from 'lucide-react';
import { Label } from '@/components/ui/label';

export const colorMap = {
  'Maroon': '#800000',
  'Navy Blue': '#000080',
  'Gold': '#D4AF37',
  'Cream': '#F5F1E8',
  'Peach': '#FFE5B4',
  'Mint Green': '#98FF98',
  'Burgundy': '#800020',
  'Teal': '#008080',
  'Rose Gold': '#B76E79',
  'Multicolor': 'conic-gradient(red, yellow, green, blue, purple)',
  'Black': '#000000',
  'White': '#FFFFFF',
  'Purple': '#800080',
  'Olive Green': '#808000',
  'Coral': '#FF7F50',
  'Rust': '#B7410E',
  'Indigo': '#4B0082',
  'Silver': '#C0C0C0',
  'Champagne': '#F7E7CE',
  'Emerald': '#50C878',
  'Saffron': '#F4C430',
  'Blush Pink': '#FE828C',
  'Deep Purple': '#36013F',
  'Beige': '#F5F5DC',
  'Charcoal': '#36454F'
};

const ColorSelector = ({ colors = [], selectedColor, onSelectColor }) => {
  if (!colors || colors.length === 0) return null;

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <Label className="label-luxury text-lg">Select Color</Label>
        <span className="text-base text-gold-dark font-serif font-bold">{selectedColor || 'None selected'}</span>
      </div>
      <div className="flex flex-wrap gap-4">
        {colors.map((color) => {
          const isSelected = selectedColor === color;
          const backgroundStyle = colorMap[color] || '#CCCCCC';
          const isLight = ['White', 'Cream', 'Beige', 'Champagne', 'Mint Green', 'Peach'].includes(color);

          return (
            <button
              key={color}
              onClick={() => onSelectColor(color)}
              className={`relative w-12 h-12 rounded-full border-2 transition-all duration-300 flex items-center justify-center ${
                isSelected ? 'border-gold scale-110 shadow-gold' : 'border-gold/30 hover:scale-105 hover:border-gold hover:shadow-sm'
              }`}
              style={{
                background: backgroundStyle.includes('gradient') ? backgroundStyle : undefined,
                backgroundColor: !backgroundStyle.includes('gradient') ? backgroundStyle : undefined,
                boxShadow: isSelected ? '0 0 0 3px #F5F1E8, 0 0 0 5px #D4AF37' : undefined
              }}
              title={color}
              aria-label={`Select ${color}`}
            >
              {isSelected && (
                <Check className={`w-6 h-6 ${isLight ? 'text-forest-green' : 'text-white'}`} strokeWidth={3} />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default ColorSelector;