import React from 'react';
import { SlidersHorizontal } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const FilterBar = ({ selectedCategory, onCategoryChange, sortBy, onSortChange, categoryCounts }) => {
  const categories = [
    { id: 'all', label: 'All Products' },
    { id: 'kurti', label: 'Kurtis' },
    { id: 'jeans', label: 'Jeans' },
  ];

  return (
    <div className="flex flex-col md:flex-row items-center justify-between gap-6 bg-background p-4 rounded-xl border border-primary/30 shadow-sm">
      {/* Category Tabs */}
      <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
        {categories.map((cat) => {
          const isActive = selectedCategory === cat.id;
          const count = categoryCounts[cat.id] || 0;
          
          return (
            <button
              key={cat.id}
              onClick={() => onCategoryChange(cat.id)}
              className={`px-6 py-2.5 rounded-full font-serif text-base font-medium transition-all duration-300 border ${
                isActive
                  ? 'bg-primary text-primary-foreground border-primary shadow-[var(--gold-shadow)]'
                  : 'bg-background text-foreground border-primary hover:bg-primary/10'
              }`}
            >
              {cat.label} <span className="ml-1 opacity-80 text-sm">({count})</span>
            </button>
          );
        })}
      </div>

      {/* Sort Dropdown */}
      <div className="flex items-center gap-3 w-full md:w-auto">
        <SlidersHorizontal className="w-5 h-5 text-primary hidden sm:block" />
        <Select value={sortBy} onValueChange={onSortChange}>
          <SelectTrigger className="w-full md:w-[220px] input-luxury py-5 text-base font-serif">
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent className="bg-background border-primary">
            <SelectItem value="newest" className="font-serif text-foreground focus:bg-primary/10 focus:text-primary cursor-pointer">Newest</SelectItem>
            <SelectItem value="price-low" className="font-serif text-foreground focus:bg-primary/10 focus:text-primary cursor-pointer">Price: Low to High</SelectItem>
            <SelectItem value="price-high" className="font-serif text-foreground focus:bg-primary/10 focus:text-primary cursor-pointer">Price: High to Low</SelectItem>
            <SelectItem value="rating" className="font-serif text-foreground focus:bg-primary/10 focus:text-primary cursor-pointer">Best Sellers</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};

export default FilterBar;