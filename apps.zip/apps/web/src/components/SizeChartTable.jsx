import React from 'react';
import { Info } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

const SizeChartTable = () => {
  const sizeData = [
    { size: 'XS', bust: '32-34', waist: '24-26', length: '110-115' },
    { size: 'S', bust: '34-36', waist: '26-28', length: '115-120' },
    { size: 'M', bust: '36-38', waist: '28-30', length: '120-125' },
    { size: 'L', bust: '38-40', waist: '30-32', length: '125-130' },
    { size: 'XL', bust: '40-42', waist: '32-34', length: '130-135' },
    { size: 'XXL', bust: '42-44', waist: '34-36', length: '135-140' },
  ];

  return (
    <div className="w-full overflow-x-auto rounded-xl border-2 border-gold shadow-sm">
      <div className="flex items-center justify-between p-5 bg-gold text-cream">
        <h3 className="font-serif text-2xl font-bold">Standard Size Chart</h3>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <button className="p-1.5 hover:bg-white/20 rounded-full transition-colors">
                <Info className="w-6 h-6" />
              </button>
            </TooltipTrigger>
            <TooltipContent className="max-w-xs bg-cream text-forest-green border-gold font-sans">
              <p>Measurements are in centimeters (cm). For the best fit, measure yourself over your undergarments. If you fall between sizes, we recommend choosing the larger size or opting for our Custom Fit.</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
      <table className="w-full text-left border-collapse">
        <thead>
          <tr className="bg-light-gold text-forest-green font-serif text-lg border-b-2 border-gold">
            <th className="p-5 font-bold">Size</th>
            <th className="p-5 font-bold">Bust (cm)</th>
            <th className="p-5 font-bold">Waist (cm)</th>
            <th className="p-5 font-bold">Length (cm)</th>
          </tr>
        </thead>
        <tbody>
          {sizeData.map((row, index) => (
            <tr
              key={row.size}
              className={`border-b border-gold/20 transition-colors hover:bg-gold/10 ${
                index % 2 === 0 ? 'bg-cream' : 'bg-light-gold'
              }`}
            >
              <td className="p-5 font-serif font-bold text-forest-green text-lg">{row.size}</td>
              <td className="p-5 text-forest-green/80 font-medium">{row.bust}</td>
              <td className="p-5 text-forest-green/80 font-medium">{row.waist}</td>
              <td className="p-5 text-forest-green/80 font-medium">{row.length}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default SizeChartTable;