import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle2, Ruler, AlertCircle } from 'lucide-react';
import MeasurementDiagrams from './MeasurementDiagrams.jsx';

const CustomMeasurementGuide = () => {
  const tips = [
    "Use a soft, flexible measuring tape.",
    "Wear fitted clothing or undergarments.",
    "Get a friend to help for accurate results.",
    "Measure twice to ensure accuracy.",
    "Keep the tape parallel to the ground.",
    "Don't pull the tape too tight; keep it comfortable."
  ];

  const chartData = [
    { type: 'Petite', bust: '80-84', waist: '60-64', length: '105-110', size: 'XS' },
    { type: 'Small', bust: '85-89', waist: '65-69', length: '110-115', size: 'S' },
    { type: 'Medium', bust: '90-94', waist: '70-74', length: '115-120', size: 'M' },
    { type: 'Large', bust: '95-99', waist: '75-79', length: '120-125', size: 'L' },
    { type: 'XL', bust: '100-104', waist: '80-84', length: '125-130', size: 'XL' },
    { type: 'XXL', bust: '105-109', waist: '85-89', length: '130-135', size: 'XXL' },
  ];

  return (
    <div className="space-y-16">
      {/* How to Measure */}
      <section>
        <h3 className="font-serif text-3xl font-bold text-forest-green mb-8 flex items-center gap-3 border-b-2 border-gold/30 pb-4">
          <Ruler className="w-8 h-8 text-gold" />
          How to Measure
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Bust */}
          <Card className="border-2 border-gold bg-cream shadow-sm hover:shadow-gold transition-shadow">
            <CardContent className="p-8 text-center">
              <MeasurementDiagrams type="bust" />
              <h4 className="font-serif text-2xl font-bold text-forest-green mt-8 mb-3">Bust</h4>
              <p className="text-forest-green/80 text-base mb-6 h-12">Measure around the fullest part of your bust, keeping the tape horizontal.</p>
              <div className="bg-white p-4 rounded-lg text-sm text-forest-green font-medium border border-gold/30 shadow-sm">
                <span className="text-gold font-bold mr-2 uppercase tracking-wider">Tip:</span> Wear the bra you intend to wear with the outfit.
              </div>
            </CardContent>
          </Card>
          {/* Waist */}
          <Card className="border-2 border-gold bg-cream shadow-sm hover:shadow-gold transition-shadow">
            <CardContent className="p-8 text-center">
              <MeasurementDiagrams type="waist" />
              <h4 className="font-serif text-2xl font-bold text-forest-green mt-8 mb-3">Waist</h4>
              <p className="text-forest-green/80 text-base mb-6 h-12">Measure around the narrowest part of your natural waistline.</p>
              <div className="bg-white p-4 rounded-lg text-sm text-forest-green font-medium border border-gold/30 shadow-sm">
                <span className="text-gold font-bold mr-2 uppercase tracking-wider">Tip:</span> Don't suck in your stomach; stand naturally.
              </div>
            </CardContent>
          </Card>
          {/* Length */}
          <Card className="border-2 border-gold bg-cream shadow-sm hover:shadow-gold transition-shadow">
            <CardContent className="p-8 text-center">
              <MeasurementDiagrams type="length" />
              <h4 className="font-serif text-2xl font-bold text-forest-green mt-8 mb-3">Length</h4>
              <p className="text-forest-green/80 text-base mb-6 h-12">Measure from the highest point of your shoulder down to your desired hemline.</p>
              <div className="bg-white p-4 rounded-lg text-sm text-forest-green font-medium border border-gold/30 shadow-sm">
                <span className="text-gold font-bold mr-2 uppercase tracking-wider">Tip:</span> Stand straight and look forward while measuring.
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Reference Chart */}
      <section>
        <h3 className="font-serif text-3xl font-bold text-forest-green mb-8 border-b-2 border-gold/30 pb-4">Custom Measurement Reference Chart</h3>
        <div className="overflow-x-auto rounded-xl border-2 border-gold shadow-sm">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gold text-cream font-serif text-lg">
                <th className="p-5 font-bold">Body Type</th>
                <th className="p-5 font-bold">Bust (cm)</th>
                <th className="p-5 font-bold">Waist (cm)</th>
                <th className="p-5 font-bold">Length (cm)</th>
                <th className="p-5 font-bold">Suggested Size</th>
              </tr>
            </thead>
            <tbody>
              {chartData.map((row, index) => (
                <tr key={row.type} className={`border-b border-gold/20 transition-colors hover:bg-gold/10 ${index % 2 === 0 ? 'bg-cream' : 'bg-light-gold'}`}>
                  <td className="p-5 font-serif font-bold text-forest-green text-lg">{row.type}</td>
                  <td className="p-5 text-forest-green/80 font-medium">{row.bust}</td>
                  <td className="p-5 text-forest-green/80 font-medium">{row.waist}</td>
                  <td className="p-5 text-forest-green/80 font-medium">{row.length}</td>
                  <td className="p-5 font-serif font-bold text-gold text-xl">{row.size}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Custom vs Standard */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="border-2 border-gold bg-forest-green text-cream shadow-gold">
          <CardHeader className="border-b border-gold/30 pb-6">
            <CardTitle className="font-serif text-3xl text-gold">Why Custom Fit?</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6 pt-6">
            <div className="flex items-start gap-4">
              <CheckCircle2 className="w-6 h-6 text-gold flex-shrink-0 mt-0.5" />
              <p className="text-lg">Perfect fit tailored exactly to your unique body shape.</p>
            </div>
            <div className="flex items-start gap-4">
              <CheckCircle2 className="w-6 h-6 text-gold flex-shrink-0 mt-0.5" />
              <p className="text-lg">No need for alterations or returns due to sizing issues.</p>
            </div>
            <div className="flex items-start gap-4">
              <CheckCircle2 className="w-6 h-6 text-gold flex-shrink-0 mt-0.5" />
              <p className="text-lg">Ideal if you fall between standard sizes or have specific preferences.</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-2 border-gold bg-cream shadow-sm">
          <CardHeader className="border-b border-gold/30 pb-6">
            <CardTitle className="font-serif text-3xl text-forest-green">When to use Standard?</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6 pt-6">
            <div className="flex items-start gap-4">
              <AlertCircle className="w-6 h-6 text-gold flex-shrink-0 mt-0.5" />
              <p className="text-lg text-forest-green/80">If your measurements perfectly align with our size chart.</p>
            </div>
            <div className="flex items-start gap-4">
              <AlertCircle className="w-6 h-6 text-gold flex-shrink-0 mt-0.5" />
              <p className="text-lg text-forest-green/80">When you need faster delivery (standard sizes ship quicker).</p>
            </div>
            <div className="flex items-start gap-4">
              <AlertCircle className="w-6 h-6 text-gold flex-shrink-0 mt-0.5" />
              <p className="text-lg text-forest-green/80">If you prefer a standard fit and are comfortable with minor local alterations.</p>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Measurement Tips */}
      <section>
        <h3 className="font-serif text-3xl font-bold text-forest-green mb-8 border-b-2 border-gold/30 pb-4">Measurement Tips</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {tips.map((tip, index) => (
            <div key={index} className="bg-white p-6 rounded-xl border-2 border-gold/30 flex items-start gap-4 shadow-sm hover:shadow-gold hover:border-gold transition-all">
              <div className="bg-gold text-cream w-8 h-8 rounded-full flex items-center justify-center font-serif font-bold flex-shrink-0 text-lg">
                {index + 1}
              </div>
              <p className="text-forest-green/80 text-base pt-1 font-medium">{tip}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default CustomMeasurementGuide;