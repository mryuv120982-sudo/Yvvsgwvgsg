import React from 'react';
import { Palette, Scissors, CalendarHeart, Droplets } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { colorMap } from './ColorSelector.jsx';

const StyleColorChart = ({ product }) => {
  if (!product) return null;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      {/* Colors Section */}
      <Card className="border-2 border-gold bg-cream shadow-sm">
        <CardContent className="p-8">
          <div className="flex items-center gap-3 mb-6 border-b border-gold/30 pb-4">
            <Palette className="w-6 h-6 text-gold" />
            <h3 className="font-serif text-2xl font-bold text-forest-green">Available Colors</h3>
          </div>
          {product.colors && product.colors.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {product.colors.map((color) => {
                const backgroundStyle = colorMap[color] || '#CCCCCC';
                return (
                  <div key={color} className="flex items-center gap-3 p-3 rounded-lg bg-white border border-gold/20 hover:border-gold hover:shadow-sm transition-all">
                    <div 
                      className="w-8 h-8 rounded-full shadow-sm border-2 border-gold/30"
                      style={{
                        background: backgroundStyle.includes('gradient') ? backgroundStyle : undefined,
                        backgroundColor: !backgroundStyle.includes('gradient') ? backgroundStyle : undefined,
                      }}
                    />
                    <span className="text-sm text-forest-green font-bold font-serif">{color}</span>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-forest-green/60 italic font-serif">Standard color shown in image.</p>
          )}
        </CardContent>
      </Card>

      {/* Style & Care Details */}
      <div className="space-y-6">
        <Card className="border-2 border-gold bg-cream shadow-sm">
          <CardContent className="p-6 flex items-start gap-4">
            <div className="bg-light-gold p-3 rounded-full border border-gold/30">
              <Scissors className="w-6 h-6 text-gold" />
            </div>
            <div>
              <h3 className="font-serif text-xl font-bold text-forest-green mb-1">Fabric</h3>
              <p className="text-forest-green/80">{product.fabric || 'Premium quality blend'}</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-gold bg-cream shadow-sm">
          <CardContent className="p-6 flex items-start gap-4">
            <div className="bg-light-gold p-3 rounded-full border border-gold/30">
              <CalendarHeart className="w-6 h-6 text-gold" />
            </div>
            <div>
              <h3 className="font-serif text-xl font-bold text-forest-green mb-1">Occasion</h3>
              <p className="text-forest-green/80">{product.occasion || 'Versatile wear'}</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-gold bg-cream shadow-sm">
          <CardContent className="p-6 flex items-start gap-4">
            <div className="bg-light-gold p-3 rounded-full border border-gold/30">
              <Droplets className="w-6 h-6 text-gold" />
            </div>
            <div>
              <h3 className="font-serif text-xl font-bold text-forest-green mb-1">Care Instructions</h3>
              <p className="text-forest-green/80">{product.care_instructions || 'Dry clean recommended. Do not bleach.'}</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default StyleColorChart;