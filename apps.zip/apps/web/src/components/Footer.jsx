import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Twitter, Mail, Phone, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import pb from '@/lib/pocketbaseClient';

const Footer = () => {
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleNewsletterSignup = async (e) => {
    e.preventDefault();
    
    if (!email) {
      toast({
        title: 'Email Required',
        description: 'Please enter your email address',
        variant: 'destructive',
      });
      return;
    }

    setIsSubmitting(true);
    try {
      await pb.collection('newsletter_signups').create({ email }, { $autoCancel: false });
      toast({
        title: 'Success!',
        description: 'Thank you for subscribing to our newsletter!',
      });
      setEmail('');
    } catch (error) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to subscribe. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const quickLinks = [
    { name: 'Shop', path: '/shop' },
    { name: 'About Us', path: '/about' },
    { name: 'Contact', path: '/contact' },
    { name: 'FAQ', path: '/about' },
  ];

  return (
    <footer className="bg-forest-green text-cream relative">
      {/* Ornate Top Border */}
      <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-gold-dark via-gold to-gold-dark"></div>
      <div className="absolute top-[3px] left-0 w-full h-1 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iNCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIyIiBjeT0iMiIgcj0iMSIgZmlsbD0iI0Q0QUYzNyIvPjwvc3ZnPg==')] opacity-50"></div>

      <div className="container mx-auto px-4 py-16 mt-2">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand Section */}
          <div>
            <img
              src="https://horizons-cdn.hostinger.com/61ab4a5d-d70f-4c40-81bb-9b5fc1c3d2cd/28dd30a360c51a3d175f7263a5a1a455.jpg"
              alt="Pehrin Logo"
              className="h-16 w-auto mb-6 brightness-0 invert"
            />
            <p className="text-cream/90 leading-relaxed mb-6 font-sans">
              Bringing celebrity fashion and custom fits to every girl's doorstep at an affordable price.
            </p>
            <div className="flex gap-5">
              <a href="#" className="text-cream hover:text-gold transition-colors duration-300">
                <Facebook className="w-6 h-6" />
              </a>
              <a href="#" className="text-cream hover:text-gold transition-colors duration-300">
                <Instagram className="w-6 h-6" />
              </a>
              <a href="#" className="text-cream hover:text-gold transition-colors duration-300">
                <Twitter className="w-6 h-6" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-serif text-2xl font-bold mb-6 text-gold">Quick Links</h3>
            <ul className="space-y-4">
              {quickLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-cream/90 hover:text-gold hover:underline transition-all duration-300 font-sans"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h3 className="font-serif text-2xl font-bold mb-6 text-gold">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 text-cream/90 font-sans">
                <Phone className="w-5 h-5 mt-0.5 text-gold flex-shrink-0" />
                <span>+91 98765 43210</span>
              </li>
              <li className="flex items-start gap-3 text-cream/90 font-sans">
                <Mail className="w-5 h-5 mt-0.5 text-gold flex-shrink-0" />
                <span>support@pehrin.com</span>
              </li>
              <li className="flex items-start gap-3 text-cream/90 font-sans">
                <MapPin className="w-5 h-5 mt-0.5 text-gold flex-shrink-0" />
                <span>Mumbai, Maharashtra, India</span>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="font-serif text-2xl font-bold mb-6 text-gold">Newsletter</h3>
            <p className="text-cream/90 mb-6 font-sans">
              Subscribe to get special offers and updates!
            </p>
            <form onSubmit={handleNewsletterSignup} className="space-y-3">
              <Input
                type="email"
                placeholder="Your email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-cream border border-gold focus-visible:ring-0 focus-visible:border-2 focus-visible:border-gold focus-visible:shadow-rose text-forest-green placeholder:text-gold-dark rounded-md transition-all duration-300"
                disabled={isSubmitting}
              />
              <Button
                type="submit"
                className="w-full bg-gold text-cream hover:bg-gold-dark hover:text-rose-blush font-serif font-bold rounded-md transition-all duration-300 py-6"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Subscribing...' : 'Subscribe'}
              </Button>
            </form>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gold/30 mt-16 pt-8 text-center">
          <p className="text-cream/80 font-sans">
            © {new Date().getFullYear()} Pehrin. All rights reserved. | Because Your Style Isn't Basic
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;