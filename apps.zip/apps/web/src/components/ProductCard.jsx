import React from 'react';
import { Link } from 'react-router-dom';
import { Star, ShoppingCart } from 'lucide-react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';

const ProductCard = ({ product }) => {
  const { toast } = useToast();
  
  const imageUrl = product.image 
    ? `https://via.placeholder.com/600x600/F5F1E8/2D5016?text=${encodeURIComponent(product.name)}`
    : 'https://via.placeholder.com/600x600/F5F1E8/2D5016?text=Product';

  const handleQuickAdd = (e) => {
    e.preventDefault();
    e.stopPropagation();
    
    const cartItem = {
      productId: product.id,
      name: product.name,
      price: product.price,
      quantity: 1,
      color: product.colors?.[0] || 'Standard',
      sizeType: 'standard',
      standardSize: 'M',
      image: product.image,
    };

    const cart = JSON.parse(localStorage.getItem('pehrin_cart') || '[]');
    const existingIndex = cart.findIndex(
      (item) => item.productId === cartItem.productId && item.sizeType === 'standard' && item.standardSize === 'M'
    );

    if (existingIndex >= 0) {
      cart[existingIndex].quantity += 1;
    } else {
      cart.push(cartItem);
    }

    localStorage.setItem('pehrin_cart', JSON.stringify(cart));
    window.dispatchEvent(new Event('cartUpdated'));

    toast({
      title: 'Added to Cart',
      description: `${product.name} added to your cart.`,
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      whileHover={{ y: -5, scale: 1.02 }}
      className="h-full"
    >
      <Card className="h-full flex flex-col overflow-hidden border border-primary bg-background hover:shadow-[var(--gold-shadow)] transition-all duration-300 relative group p-4 sm:p-5">
        
        {/* Image Container */}
        <Link to={`/product/${product.id}`} className="flex-shrink-0 relative block overflow-hidden rounded-md border border-primary/20 bg-[#FAF8F3]">
          <div className="aspect-square w-full">
            <img
              src={imageUrl}
              alt={product.name}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
          </div>
          
          {/* Category Badge */}
          <Badge className="absolute top-3 right-3 bg-primary text-primary-foreground font-serif font-bold rounded-md px-3 py-1 shadow-sm hover:bg-primary">
            {product.category === 'kurti' ? 'Kurti' : 'Jeans'}
          </Badge>
        </Link>
        
        <CardContent className="p-0 pt-5 flex-grow flex flex-col justify-between">
          <div>
            <Link to={`/product/${product.id}`}>
              <h3 className="font-serif text-lg sm:text-xl font-bold text-foreground mb-2 hover:text-primary transition-colors line-clamp-2 leading-snug min-h-[3.5rem]">
                {product.name}
              </h3>
            </Link>
            
            <div className="flex items-center gap-1 mb-4">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-4 h-4 ${
                    i < Math.floor(product.rating || 0)
                      ? 'fill-accent text-accent'
                      : 'text-primary/30'
                  }`}
                />
              ))}
              <span className="text-sm text-foreground/60 ml-2 font-medium">
                ({product.rating || 0})
              </span>
            </div>
          </div>
          
          <div className="flex items-center justify-between mt-auto pt-2">
            <p className="text-2xl font-serif font-bold text-primary">
              ₹{product.price?.toLocaleString('en-IN')}
            </p>
            
            {/* Quick Add Button */}
            <button 
              onClick={handleQuickAdd}
              className="w-10 h-10 rounded-full bg-background border border-primary flex items-center justify-center text-primary hover:bg-accent hover:text-primary-foreground hover:border-accent transition-colors shadow-sm"
              aria-label="Add to cart"
            >
              <ShoppingCart className="w-5 h-5" />
            </button>
          </div>
        </CardContent>
        
        <CardFooter className="p-0 pt-5">
          <Link to={`/product/${product.id}`} className="w-full">
            <Button className="w-full btn-primary py-5 text-base">
              View Details
            </Button>
          </Link>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default ProductCard;