import React from 'react';

const MeasurementDiagrams = ({ type }) => {
  return (
    <svg viewBox="0 0 100 200" className="w-full max-w-[140px] mx-auto h-auto drop-shadow-sm">
      {/* Head */}
      <circle cx="50" cy="25" r="12" fill="#F5F1E8" stroke="#2D5016" strokeWidth="2"/>
      {/* Neck */}
      <path d="M 45 37 L 45 45 L 55 45 L 55 37" fill="#F5F1E8" stroke="#2D5016" strokeWidth="2"/>
      {/* Body Silhouette */}
      <path 
        d="M 45 45 Q 20 45 15 65 L 25 110 L 30 105 L 20 190 L 80 190 L 70 105 L 75 110 L 85 65 Q 80 45 55 45" 
        fill="#F5F1E8" 
        stroke="#2D5016" 
        strokeWidth="2" 
        strokeLinejoin="round"
      />
      
      {/* Bust Line */}
      {type === 'bust' && (
        <g>
          <line x1="18" y1="75" x2="82" y2="75" stroke="#D4AF37" strokeWidth="3" strokeDasharray="4"/>
          <rect x="30" y="67" width="40" height="16" fill="#F5F1E8" rx="4" stroke="#2D5016" strokeWidth="1"/>
          <text x="50" y="79" textAnchor="middle" fill="#2D5016" fontSize="10" fontWeight="bold" letterSpacing="1">BUST</text>
        </g>
      )}
      
      {/* Waist Line */}
      {type === 'waist' && (
        <g>
          <line x1="26" y1="110" x2="74" y2="110" stroke="#D4AF37" strokeWidth="3" strokeDasharray="4"/>
          <rect x="28" y="102" width="44" height="16" fill="#F5F1E8" rx="4" stroke="#2D5016" strokeWidth="1"/>
          <text x="50" y="114" textAnchor="middle" fill="#2D5016" fontSize="10" fontWeight="bold" letterSpacing="1">WAIST</text>
        </g>
      )}
      
      {/* Length Line */}
      {type === 'length' && (
        <g>
          <line x1="35" y1="45" x2="35" y2="185" stroke="#D4AF37" strokeWidth="3" strokeDasharray="4"/>
          <rect x="27" y="95" width="16" height="50" fill="#F5F1E8" rx="4" stroke="#2D5016" strokeWidth="1"/>
          <text x="31" y="120" textAnchor="middle" fill="#2D5016" fontSize="10" fontWeight="bold" letterSpacing="1" transform="rotate(-90 31 120)">LENGTH</text>
        </g>
      )}
    </svg>
  );
};

export default MeasurementDiagrams;