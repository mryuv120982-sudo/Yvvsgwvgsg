import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Heart, Users, Award, Sparkles } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const AboutPage = () => {
  const values = [
    {
      icon: Heart,
      title: 'Customer First',
      description: 'Your satisfaction and comfort are our top priorities',
    },
    {
      icon: Award,
      title: 'Quality Assured',
      description: 'Premium fabrics and expert craftsmanship in every piece',
    },
    {
      icon: Sparkles,
      title: 'Trendy Designs',
      description: 'Celebrity-inspired styles that keep you ahead of fashion',
    },
    {
      icon: Users,
      title: 'Inclusive Fashion',
      description: 'Custom fits for every body type and size',
    },
  ];

  return (
    <>
      <Helmet>
        <title>About Us - Pehrin</title>
        <meta name="description" content="Learn about Pehrin's mission to bring celebrity fashion and custom fits to every girl's doorstep at affordable prices." />
      </Helmet>

      <div className="min-h-screen bg-cream">
        <Header />

        {/* Hero Section */}
        <section className="pt-32 pb-16 px-4 bg-forest-green text-white">
          <div className="container mx-auto max-w-4xl text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="font-serif text-5xl md:text-6xl font-bold mb-6">
                About Pehrin
              </h1>
              <p className="text-xl md:text-2xl text-cream leading-relaxed">
                Because Your Style Isn't Basic
              </p>
            </motion.div>
          </div>
        </section>

        {/* Mission Section */}
        <section className="py-20 px-4">
          <div className="container mx-auto max-w-4xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="text-center mb-16"
            >
              <h2 className="font-serif text-4xl md:text-5xl font-bold text-forest-green mb-6">
                Our Mission
              </h2>
              <p className="text-xl text-gray-700 leading-relaxed">
                At Pehrin, we're on a mission to democratize fashion. We believe every woman deserves to wear 
                clothes that make her feel confident, beautiful, and uniquely herself. That's why we bring 
                celebrity-inspired styles and custom-tailored pieces directly to your doorstep, without the 
                premium price tag.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
              className="bg-white p-8 md:p-12 rounded-lg shadow-xl border-2 border-gold/20"
            >
              <h3 className="font-serif text-3xl font-bold text-forest-green mb-4">
                What Makes Us Different
              </h3>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                We understand that every woman is unique, and so are her style preferences and body measurements. 
                That's why we offer both standard sizes and custom fit options for all our products. Whether you're 
                looking for a trendy kurti for a casual day out or perfectly fitted jeans for a night on the town, 
                we've got you covered.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed">
                Our team carefully curates each collection, drawing inspiration from the latest celebrity fashion 
                trends and adapting them to suit the Indian woman's lifestyle and preferences. We work with skilled 
                artisans and use premium quality fabrics to ensure that every piece you receive is worth cherishing.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-20 px-4 bg-white">
          <div className="container mx-auto max-w-6xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="font-serif text-4xl md:text-5xl font-bold text-forest-green mb-4">
                Our Values
              </h2>
              <p className="text-xl text-gray-600">
                The principles that guide everything we do
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {values.map((value, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="text-center p-6 rounded-lg border-2 border-gold/20 hover:border-gold/40 transition-all duration-300 hover:shadow-lg"
                >
                  <value.icon className="w-12 h-12 text-gold mx-auto mb-4" />
                  <h3 className="font-serif text-xl font-semibold text-forest-green mb-2">
                    {value.title}
                  </h3>
                  <p className="text-gray-600">{value.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-20 px-4">
          <div className="container mx-auto max-w-4xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="font-serif text-4xl md:text-5xl font-bold text-forest-green mb-4">
                Frequently Asked Questions
              </h2>
            </motion.div>

            <div className="space-y-6">
              {[
                {
                  q: 'How do custom measurements work?',
                  a: 'Simply select the "Custom Fit" option when adding a product to your cart, and enter your bust, waist, and length measurements in centimeters. Our skilled tailors will create a piece that fits you perfectly.',
                },
                {
                  q: 'What is your return policy?',
                  a: 'We offer a 7-day return policy for standard sizes. Custom-fit items are made specifically for you and cannot be returned unless there is a manufacturing defect.',
                },
                {
                  q: 'How long does delivery take?',
                  a: 'Standard items are delivered within 5-7 business days. Custom-fit items may take 10-14 business days as they are tailored specifically for you.',
                },
                {
                  q: 'Do you ship across India?',
                  a: 'Yes! We deliver to all major cities and towns across India. Shipping charges may vary based on your location.',
                },
              ].map((faq, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="bg-white p-6 rounded-lg shadow-md border border-gold/20"
                >
                  <h3 className="font-serif text-xl font-semibold text-forest-green mb-2">
                    {faq.q}
                  </h3>
                  <p className="text-gray-700">{faq.a}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default AboutPage;