import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { User, Package, MapPin, Phone, Mail } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext.jsx';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import pb from '@/lib/pocketbaseClient';

const UserProfile = () => {
  const { currentUser } = useAuth();
  const [orders, setOrders] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const records = await pb.collection('orders').getList(1, 50, {
          filter: `userId = "${currentUser.id}"`,
          sort: '-created',
          $autoCancel: false,
        });
        setOrders(records.items);
      } catch (error) {
        console.error('Error fetching orders:', error);
      } finally {
        setIsLoading(false);
      }
    };

    if (currentUser) {
      fetchOrders();
    }
  }, [currentUser]);

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending':
        return 'bg-light-gold text-gold-dark border border-gold';
      case 'confirmed':
        return 'bg-blue-50 text-blue-800 border border-blue-200';
      case 'shipped':
        return 'bg-purple-50 text-purple-800 border border-purple-200';
      case 'delivered':
        return 'bg-green-50 text-forest-green border border-forest-green/30';
      default:
        return 'bg-gray-50 text-gray-800 border border-gray-200';
    }
  };

  return (
    <>
      <Helmet>
        <title>My Profile - Pehrin</title>
        <meta name="description" content="View your account information and order history" />
      </Helmet>

      <div className="min-h-screen bg-cream">
        <Header />

        <div className="pt-32 pb-24 px-4">
          <div className="container mx-auto max-w-6xl">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="font-serif text-5xl md:text-6xl font-bold text-forest-green mb-12 text-center"
            >
              My Profile
            </motion.h1>

            <Tabs defaultValue="account" className="space-y-8">
              <TabsList className="grid w-full md:w-auto grid-cols-2 bg-light-gold border-2 border-gold p-1 rounded-xl mx-auto max-w-md">
                <TabsTrigger value="account" className="data-[state=active]:bg-gold data-[state=active]:text-cream font-serif text-xl py-3 rounded-lg transition-all text-forest-green">
                  <User className="w-5 h-5 mr-2" />
                  Account
                </TabsTrigger>
                <TabsTrigger value="orders" className="data-[state=active]:bg-gold data-[state=active]:text-cream font-serif text-xl py-3 rounded-lg transition-all text-forest-green">
                  <Package className="w-5 h-5 mr-2" />
                  Orders
                </TabsTrigger>
              </TabsList>

              {/* Account Tab */}
              <TabsContent value="account">
                <Card className="border-2 border-gold bg-white shadow-sm max-w-3xl mx-auto">
                  <CardHeader className="border-b border-gold/30 bg-light-gold">
                    <CardTitle className="font-serif text-3xl text-forest-green">
                      Account Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6 p-8">
                    <div className="flex items-center gap-4 p-5 bg-cream border border-gold/30 rounded-lg">
                      <div className="bg-gold/10 p-3 rounded-full">
                        <User className="w-6 h-6 text-gold" />
                      </div>
                      <div>
                        <p className="text-sm text-forest-green/70 font-bold uppercase tracking-wider">Name</p>
                        <p className="font-serif text-xl font-bold text-forest-green">{currentUser?.name || 'Not set'}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 p-5 bg-cream border border-gold/30 rounded-lg">
                      <div className="bg-gold/10 p-3 rounded-full">
                        <Mail className="w-6 h-6 text-gold" />
                      </div>
                      <div>
                        <p className="text-sm text-forest-green/70 font-bold uppercase tracking-wider">Email</p>
                        <p className="font-serif text-xl font-bold text-forest-green">{currentUser?.email}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 p-5 bg-cream border border-gold/30 rounded-lg">
                      <div className="bg-gold/10 p-3 rounded-full">
                        <Package className="w-6 h-6 text-gold" />
                      </div>
                      <div>
                        <p className="text-sm text-forest-green/70 font-bold uppercase tracking-wider">Total Orders</p>
                        <p className="font-serif text-xl font-bold text-forest-green">{orders.length}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Orders Tab */}
              <TabsContent value="orders">
                {isLoading ? (
                  <div className="text-center py-16">
                    <div className="w-16 h-16 border-4 border-gold border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                    <p className="text-forest-green font-serif text-xl">Loading orders...</p>
                  </div>
                ) : orders.length === 0 ? (
                  <Card className="border-2 border-gold border-dashed bg-white shadow-sm">
                    <CardContent className="py-20 text-center">
                      <Package className="w-20 h-20 text-gold mx-auto mb-6" />
                      <p className="text-3xl font-serif font-bold text-forest-green mb-4">No orders yet</p>
                      <p className="text-forest-green/70 text-lg">Start shopping to see your orders here</p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="space-y-8">
                    {orders.map((order) => (
                      <motion.div
                        key={order.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3 }}
                      >
                        <Card className="border-2 border-gold bg-white shadow-sm hover:shadow-gold transition-shadow duration-300">
                          <CardHeader className="border-b border-gold/30 bg-light-gold p-6">
                            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                              <div>
                                <CardTitle className="font-serif text-2xl font-bold text-forest-green">
                                  Order #{order.id.slice(0, 8)}
                                </CardTitle>
                                <p className="text-forest-green/70 mt-1 font-medium">
                                  {new Date(order.created).toLocaleDateString('en-IN', {
                                    year: 'numeric',
                                    month: 'long',
                                    day: 'numeric',
                                  })}
                                </p>
                              </div>
                              <Badge className={`px-4 py-1.5 text-sm font-bold rounded-full ${getStatusColor(order.orderStatus)}`}>
                                {order.orderStatus.charAt(0).toUpperCase() + order.orderStatus.slice(1)}
                              </Badge>
                            </div>
                          </CardHeader>
                          <CardContent className="p-6">
                            <div className="space-y-6">
                              {/* Order Items */}
                              <div>
                                <p className="text-sm font-bold text-forest-green/70 uppercase tracking-wider mb-3">Items</p>
                                <div className="space-y-3">
                                  {order.items.map((item, index) => (
                                    <div key={index} className="flex justify-between items-start bg-cream border border-gold/20 p-4 rounded-lg">
                                      <div className="flex-1">
                                        <p className="font-serif text-lg font-bold text-forest-green">{item.name}</p>
                                        <p className="text-forest-green/80 text-sm mt-1">
                                          {item.sizeType === 'standard' 
                                            ? `Size: ${item.standardSize}` 
                                            : 'Custom Fit'
                                          } • Qty: <span className="font-bold">{item.quantity}</span>
                                        </p>
                                      </div>
                                      <p className="font-serif text-lg font-bold text-gold">
                                        ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                                      </p>
                                    </div>
                                  ))}
                                </div>
                              </div>

                              <div className="h-[1px] w-full bg-gold/30"></div>

                              {/* Delivery Address */}
                              <div>
                                <p className="text-sm font-bold text-forest-green/70 uppercase tracking-wider mb-3 flex items-center gap-2">
                                  <MapPin className="w-4 h-4 text-gold" />
                                  Delivery Address
                                </p>
                                <div className="bg-cream border border-gold/20 p-4 rounded-lg text-forest-green/80">
                                  <p className="font-serif text-lg font-bold text-forest-green mb-1">{order.deliveryAddress.name}</p>
                                  <p>{order.deliveryAddress.address}</p>
                                  <p>
                                    {order.deliveryAddress.city}, {order.deliveryAddress.state} - {order.deliveryAddress.pincode}
                                  </p>
                                  <p className="flex items-center gap-2 mt-2 font-medium">
                                    <Phone className="w-4 h-4 text-gold" />
                                    {order.deliveryAddress.phone}
                                  </p>
                                </div>
                              </div>

                              <div className="h-[1px] w-full bg-gold/30"></div>

                              {/* Total */}
                              <div className="flex justify-between items-center pt-2">
                                <p className="font-serif text-xl font-bold text-forest-green">Total Amount</p>
                                <p className="text-3xl font-serif font-bold text-gold">
                                  ₹{order.totalAmount.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                                </p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>

        <Footer />
      </div>
    </>
  );
};

export default UserProfile;