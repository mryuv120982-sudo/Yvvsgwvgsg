import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { ArrowRight, Sparkles, Heart, Truck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ProductCard from '@/components/ProductCard.jsx';
import pb from '@/lib/pocketbaseClient';

const FloralCorner = ({ className }) => (
  <svg className={`absolute w-24 h-24 text-gold opacity-40 ${className}`} viewBox="0 0 100 100" fill="currentColor">
    <path d="M0 0C40 0 70 10 100 50C100 20 80 0 50 0C80 0 100 20 100 50C70 10 40 0 0 0Z" />
    <path d="M0 0C0 40 10 70 50 100C20 100 0 80 0 50C0 80 20 100 50 100C10 70 0 40 0 0Z" />
    <circle cx="15" cy="15" r="5" />
  </svg>
);

const OrnateDivider = () => (
  <div className="flex items-center justify-center gap-4 my-10">
    <div className="h-[2px] w-32 bg-gradient-to-r from-transparent to-gold"></div>
    <div className="w-4 h-4 rotate-45 border-2 border-gold"></div>
    <div className="w-3 h-3 rotate-45 bg-gold"></div>
    <div className="w-4 h-4 rotate-45 border-2 border-gold"></div>
    <div className="h-[2px] w-32 bg-gradient-to-l from-transparent to-gold"></div>
  </div>
);

const HomePage = () => {
  const [featuredProducts, setFeaturedProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchFeaturedProducts = async () => {
      try {
        const records = await pb.collection('products').getList(1, 6, {
          sort: '-created',
          $autoCancel: false,
        });
        setFeaturedProducts(records.items);
      } catch (error) {
        console.error('Error fetching products:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchFeaturedProducts();
  }, []);

  const features = [
    {
      icon: Sparkles,
      title: 'Celebrity Fashion',
      description: 'Trending styles inspired by your favorite celebrities',
    },
    {
      icon: Heart,
      title: 'Custom Fits',
      description: 'Tailored to your exact measurements',
    },
    {
      icon: Truck,
      title: 'Fast Delivery',
      description: 'Quick doorstep delivery across India',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Pehrin - Because Your Style Isn't Basic</title>
        <meta name="description" content="Bringing celebrity fashion and custom fits to every girl's doorstep at an affordable price. Shop exclusive kurtis and jeans collections." />
      </Helmet>

      <div className="min-h-screen bg-cream">
        <Header />

        {/* Hero Section */}
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-b from-cream via-cream to-light-gold pt-20">
          {/* Decorative Corners */}
          <FloralCorner className="top-24 left-4" />
          <FloralCorner className="top-24 right-4 rotate-90" />
          <FloralCorner className="bottom-4 right-4 rotate-180" />
          <FloralCorner className="bottom-4 left-4 -rotate-90" />

          <div className="relative z-10 container mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1 }}
            >
              <h1 className="font-serif text-6xl md:text-8xl lg:text-9xl font-bold text-forest-green mb-6 tracking-tight">
                Pehrin
              </h1>
              
              <OrnateDivider />

              <h2 className="font-serif text-3xl md:text-4xl text-rose-blush italic mb-8">
                Because Your Style Isn't Basic
              </h2>
              
              <p className="text-xl md:text-2xl text-forest-green max-w-3xl mx-auto mb-12 leading-relaxed font-serif">
                Bringing celebrity fashion and custom fits to every girl's doorstep at an affordable price.
              </p>
              
              <Link to="/shop">
                <Button
                  size="lg"
                  className="btn-primary text-xl px-12 py-8 rounded-full"
                >
                  Explore Collection
                  <ArrowRight className="ml-3 w-6 h-6" />
                </Button>
              </Link>
            </motion.div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-24 bg-white border-y-2 border-gold/30 relative">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  viewport={{ once: true }}
                  className="text-center p-10 rounded-xl border-2 border-gold bg-cream hover:shadow-gold transition-all duration-500 group"
                >
                  <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-light-gold border border-gold flex items-center justify-center group-hover:scale-110 transition-transform duration-500">
                    <feature.icon className="w-10 h-10 text-gold" />
                  </div>
                  <h3 className="font-serif text-3xl font-bold text-forest-green mb-4">
                    {feature.title}
                  </h3>
                  <p className="text-lg text-forest-green/80 font-sans">{feature.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Featured Products Section */}
        <section className="py-24 bg-cream relative">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="text-center mb-16"
            >
              <h2 className="font-serif text-5xl md:text-6xl font-bold text-forest-green mb-6">
                Featured Collection
              </h2>
              <OrnateDivider />
              <p className="text-xl text-forest-green/80 max-w-2xl mx-auto font-serif italic">
                Discover our handpicked selection of trending styles
              </p>
            </motion.div>

            {isLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="bg-white rounded-lg p-4 animate-pulse border-2 border-gold/20">
                    <div className="aspect-[4/5] bg-light-gold rounded-lg mb-4"></div>
                    <div className="h-8 bg-light-gold rounded mb-3"></div>
                    <div className="h-6 bg-light-gold rounded w-2/3"></div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
                {featuredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}

            <div className="text-center mt-16">
              <Link to="/shop">
                <Button
                  size="lg"
                  className="btn-secondary text-xl px-12 py-8 rounded-full"
                >
                  View All Products
                  <ArrowRight className="ml-3 w-6 h-6" />
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Mission Statement Section */}
        <section className="py-32 bg-forest-green text-cream relative overflow-hidden">
          <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')]"></div>
          <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-gold to-transparent"></div>
          
          <div className="container mx-auto px-4 text-center relative z-10">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="font-serif text-5xl md:text-6xl font-bold mb-8 text-gold">
                Our Mission
              </h2>
              <div className="w-24 h-1 bg-rose-blush mx-auto mb-10"></div>
              <p className="text-2xl md:text-3xl text-cream max-w-5xl mx-auto leading-relaxed font-serif italic">
                "At Pehrin, we believe every woman deserves to feel confident and beautiful in clothes that fit perfectly. 
                We're revolutionizing fashion by making celebrity-inspired styles and custom-tailored pieces accessible 
                to everyone, without breaking the bank."
              </p>
            </motion.div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default HomePage;