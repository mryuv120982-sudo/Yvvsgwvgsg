import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Mail, Lock, User as UserIcon, UserPlus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { useToast } from '@/hooks/use-toast';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const SignupPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
  });
  const [isLoading, setIsLoading] = useState(false);
  const { signup } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.password || !formData.confirmPassword) {
      toast({
        title: 'Missing Information',
        description: 'Please fill in all fields',
        variant: 'destructive',
      });
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      toast({
        title: 'Password Mismatch',
        description: 'Passwords do not match',
        variant: 'destructive',
      });
      return;
    }

    if (formData.password.length < 8) {
      toast({
        title: 'Weak Password',
        description: 'Password must be at least 8 characters long',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    const result = await signup(formData.email, formData.password, formData.name);
    setIsLoading(false);

    if (result.success) {
      toast({
        title: 'Account Created!',
        description: 'Welcome to Pehrin! You are now logged in.',
      });
      navigate('/');
    } else {
      toast({
        title: 'Signup Failed',
        description: result.error || 'Failed to create account. Please try again.',
        variant: 'destructive',
      });
    }
  };

  return (
    <>
      <Helmet>
        <title>Sign Up - Pehrin</title>
        <meta name="description" content="Create your Pehrin account to access exclusive fashion collections and enjoy personalized shopping experience." />
      </Helmet>

      <div className="min-h-screen bg-cream">
        <Header />
        
        <div className="pt-32 pb-24 px-4">
          <div className="container mx-auto max-w-md">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Card className="border-2 border-gold bg-white shadow-gold relative overflow-hidden">
                {/* Decorative Top Border */}
                <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-gold-dark via-gold to-gold-dark"></div>

                <CardHeader className="text-center pt-10 pb-6">
                  <CardTitle className="font-serif text-4xl font-bold text-forest-green mb-2">Join Pehrin</CardTitle>
                  <CardDescription className="text-forest-green/70 font-serif italic text-lg">Create your account to start shopping</CardDescription>
                </CardHeader>
                
                <CardContent className="px-8">
                  <form onSubmit={handleSubmit} className="space-y-5">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="label-luxury">Full Name</Label>
                      <div className="relative">
                        <UserIcon className="absolute left-4 top-3.5 w-5 h-5 text-gold" />
                        <Input
                          id="name"
                          name="name"
                          type="text"
                          placeholder="Your name"
                          value={formData.name}
                          onChange={handleChange}
                          className="input-luxury pl-12 py-6"
                          disabled={isLoading}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email" className="label-luxury">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-4 top-3.5 w-5 h-5 text-gold" />
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          placeholder="your@email.com"
                          value={formData.email}
                          onChange={handleChange}
                          className="input-luxury pl-12 py-6"
                          disabled={isLoading}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="password" className="label-luxury">Password</Label>
                      <div className="relative">
                        <Lock className="absolute left-4 top-3.5 w-5 h-5 text-gold" />
                        <Input
                          id="password"
                          name="password"
                          type="password"
                          placeholder="••••••••"
                          value={formData.password}
                          onChange={handleChange}
                          className="input-luxury pl-12 py-6"
                          disabled={isLoading}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword" className="label-luxury">Confirm Password</Label>
                      <div className="relative">
                        <Lock className="absolute left-4 top-3.5 w-5 h-5 text-gold" />
                        <Input
                          id="confirmPassword"
                          name="confirmPassword"
                          type="password"
                          placeholder="••••••••"
                          value={formData.confirmPassword}
                          onChange={handleChange}
                          className="input-luxury pl-12 py-6"
                          disabled={isLoading}
                        />
                      </div>
                    </div>

                    <Button
                      type="submit"
                      className="w-full btn-primary py-6 text-lg mt-6"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        'Creating Account...'
                      ) : (
                        <>
                          <UserPlus className="w-5 h-5 mr-2" />
                          Sign Up
                        </>
                      )}
                    </Button>
                  </form>
                </CardContent>

                <CardFooter className="flex flex-col gap-4 pb-8 pt-4">
                  <div className="h-[1px] w-full bg-gold/30 mb-2"></div>
                  <div className="text-center text-forest-green/80 font-sans">
                    Already have an account?{' '}
                    <Link to="/login" className="text-gold hover:text-gold-dark font-bold hover:underline transition-all">
                      Login
                    </Link>
                  </div>
                </CardFooter>
              </Card>
            </motion.div>
          </div>
        </div>

        <Footer />
      </div>
    </>
  );
};

export default SignupPage;