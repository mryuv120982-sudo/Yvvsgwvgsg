import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Star, ShoppingCart, Minus, Plus, Ruler, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { useToast } from '@/hooks/use-toast';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ProductCard from '@/components/ProductCard.jsx';
import SizeChartTable from '@/components/SizeChartTable.jsx';
import StyleColorChart from '@/components/StyleColorChart.jsx';
import ColorSelector from '@/components/ColorSelector.jsx';
import CustomMeasurementGuide from '@/components/CustomMeasurementGuide.jsx';
import pb from '@/lib/pocketbaseClient';

const OrnateDivider = () => (
  <div className="flex items-center justify-center gap-4 my-8">
    <div className="h-[1px] w-full bg-gradient-to-r from-transparent to-gold"></div>
    <div className="w-2 h-2 rotate-45 bg-gold"></div>
    <div className="h-[1px] w-full bg-gradient-to-l from-transparent to-gold"></div>
  </div>
);

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [product, setProduct] = useState(null);
  const [relatedProducts, setRelatedProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [selectedColor, setSelectedColor] = useState('');
  const [sizeType, setSizeType] = useState('standard');
  const [bottomTab, setBottomTab] = useState('size-chart');
  const [standardSize, setStandardSize] = useState('M');
  const [customMeasurements, setCustomMeasurements] = useState({
    bust: '',
    waist: '',
    length: '',
  });

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const record = await pb.collection('products').getOne(id, { $autoCancel: false });
        setProduct(record);
        
        if (record.colors && record.colors.length > 0) {
          setSelectedColor(record.colors[0]);
        }

        const related = await pb.collection('products').getList(1, 4, {
          filter: `category = "${record.category}" && id != "${id}"`,
          $autoCancel: false,
        });
        setRelatedProducts(related.items);
      } catch (error) {
        console.error('Error fetching product:', error);
        toast({
          title: 'Error',
          description: 'Failed to load product details',
          variant: 'destructive',
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchProduct();
  }, [id, toast]);

  const handleAddToCart = () => {
    if (product.colors && product.colors.length > 0 && !selectedColor) {
      toast({
        title: 'Color Required',
        description: 'Please select a color before adding to cart',
        variant: 'destructive',
      });
      return;
    }

    if (sizeType === 'custom') {
      if (!customMeasurements.bust || !customMeasurements.waist || !customMeasurements.length) {
        toast({
          title: 'Missing Measurements',
          description: 'Please enter all custom measurements',
          variant: 'destructive',
        });
        return;
      }
    }

    const cartItem = {
      productId: product.id,
      name: product.name,
      price: product.price,
      quantity,
      color: selectedColor,
      sizeType,
      ...(sizeType === 'standard' ? { standardSize } : { customMeasurements }),
      image: product.image,
    };

    const cart = JSON.parse(localStorage.getItem('pehrin_cart') || '[]');
    
    const existingIndex = cart.findIndex(
      (item) => item.productId === cartItem.productId && 
      item.sizeType === cartItem.sizeType &&
      item.color === cartItem.color &&
      (item.sizeType === 'standard' ? item.standardSize === cartItem.standardSize : true)
    );

    if (existingIndex >= 0) {
      cart[existingIndex].quantity += quantity;
    } else {
      cart.push(cartItem);
    }

    localStorage.setItem('pehrin_cart', JSON.stringify(cart));
    window.dispatchEvent(new Event('cartUpdated'));

    toast({
      title: 'Added to Cart!',
      description: `${product.name} has been added to your cart`,
    });
  };

  const standardSizes = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];

  if (isLoading) {
    return (
      <>
        <Header />
        <div className="min-h-screen bg-cream flex items-center justify-center pt-20">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-gold border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-forest-green font-serif text-xl">Loading product...</p>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  if (!product) {
    return (
      <>
        <Header />
        <div className="min-h-screen bg-cream flex items-center justify-center pt-20">
          <div className="text-center">
            <p className="text-2xl text-forest-green font-serif mb-4">Product not found</p>
            <Button onClick={() => navigate('/shop')} className="btn-primary">
              Back to Shop
            </Button>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  const imageUrl = product.image 
    ? `https://via.placeholder.com/800x1000/F5F1E8/2D5016?text=${encodeURIComponent(product.name)}`
    : 'https://via.placeholder.com/800x1000/F5F1E8/2D5016?text=Product';

  return (
    <>
      <Helmet>
        <title>{`${product.name} - Pehrin`}</title>
        <meta name="description" content={product.description || `Shop ${product.name} at Pehrin. Premium quality with custom fit options.`} />
      </Helmet>

      <div className="min-h-screen bg-cream">
        <Header />

        <div className="pt-32 pb-16 px-4">
          <div className="container mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-20">
              {/* Product Image */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
              >
                <div className="sticky top-32 p-2 border-2 border-gold bg-white shadow-gold">
                  <img
                    src={imageUrl}
                    alt={product.name}
                    className="w-full object-cover"
                  />
                </div>
              </motion.div>

              {/* Product Info */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
              >
                <h1 className="font-serif text-4xl md:text-5xl font-bold text-forest-green mb-4 leading-tight">
                  {product.name}
                </h1>

                <div className="flex items-center gap-2 mb-6">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-6 h-6 ${
                        i < Math.floor(product.rating || 0)
                          ? 'fill-rose-blush text-rose-blush'
                          : 'text-gold/30'
                      }`}
                    />
                  ))}
                  <span className="text-forest-green/70 ml-2 font-medium text-lg">({product.rating || 0} Reviews)</span>
                </div>

                <p className="text-4xl font-serif font-bold text-gold mb-8">
                  ₹{product.price?.toLocaleString('en-IN')}
                </p>

                <p className="text-forest-green/80 text-lg mb-8 leading-relaxed font-sans">
                  {product.description || 'Premium quality product with excellent craftsmanship.'}
                </p>

                <OrnateDivider />

                {/* Color Selection */}
                {product.colors && product.colors.length > 0 && (
                  <div className="mb-8">
                    <ColorSelector 
                      colors={product.colors} 
                      selectedColor={selectedColor} 
                      onSelectColor={setSelectedColor} 
                    />
                  </div>
                )}

                {/* Size Selection */}
                <Card className="mb-8 border-2 border-gold bg-cream shadow-sm">
                  <CardContent className="p-6">
                    <Tabs value={sizeType} onValueChange={setSizeType}>
                      <TabsList className="grid w-full grid-cols-2 mb-8 bg-light-gold border border-gold p-1 rounded-lg">
                        <TabsTrigger value="standard" className="data-[state=active]:bg-gold data-[state=active]:text-cream font-serif text-forest-green rounded-md transition-all text-lg py-2">
                          Standard Sizes
                        </TabsTrigger>
                        <TabsTrigger value="custom" className="data-[state=active]:bg-gold data-[state=active]:text-cream font-serif text-forest-green rounded-md transition-all text-lg py-2">
                          <Ruler className="w-5 h-5 mr-2" />
                          Custom Fit
                        </TabsTrigger>
                      </TabsList>

                      <TabsContent value="standard">
                        <div className="flex items-center justify-between mb-4">
                          <Label className="label-luxury text-lg">Select Size</Label>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <button 
                                  type="button"
                                  onClick={() => {
                                    setBottomTab('size-chart');
                                    document.getElementById('comprehensive-tabs')?.scrollIntoView({ behavior: 'smooth' });
                                  }}
                                  className="text-gold hover:text-gold-dark transition-colors flex items-center font-serif font-bold"
                                >
                                  <Info className="w-5 h-5 mr-1" /> Size Guide
                                </button>
                              </TooltipTrigger>
                              <TooltipContent className="bg-cream text-forest-green border-gold">
                                <p>Check the Size Chart tab below for exact measurements.</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                        <div className="grid grid-cols-3 gap-4">
                          {standardSizes.map((size) => (
                            <Button
                              key={size}
                              variant={standardSize === size ? 'default' : 'outline'}
                              className={`font-serif text-lg py-6 ${
                                standardSize === size
                                  ? 'bg-gold text-cream hover:bg-gold-dark'
                                  : 'border-2 border-gold text-forest-green hover:bg-light-gold'
                              }`}
                              onClick={() => setStandardSize(size)}
                            >
                              {size}
                            </Button>
                          ))}
                        </div>
                      </TabsContent>

                      <TabsContent value="custom">
                        <div className="space-y-6">
                          <div className="bg-light-gold border border-gold p-4 rounded-md mb-6 text-forest-green flex items-start gap-3">
                            <Info className="w-6 h-6 flex-shrink-0 mt-0.5 text-gold" />
                            <div>
                              <p className="font-sans">Enter your exact body measurements. Our tailors will add the necessary ease for a perfect fit.</p>
                              <button 
                                type="button"
                                onClick={() => {
                                  setBottomTab('custom-guide');
                                  document.getElementById('comprehensive-tabs')?.scrollIntoView({ behavior: 'smooth' });
                                }}
                                className="text-gold font-serif font-bold hover:underline mt-2 inline-block"
                              >
                                View Custom Fit Guide
                              </button>
                            </div>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                              <Label htmlFor="bust" className="label-luxury">Bust (cm)</Label>
                              <Input
                                id="bust"
                                type="number"
                                placeholder="e.g., 86"
                                value={customMeasurements.bust}
                                onChange={(e) =>
                                  setCustomMeasurements({ ...customMeasurements, bust: e.target.value })
                                }
                                className="input-luxury mt-2"
                              />
                            </div>
                            <div>
                              <Label htmlFor="waist" className="label-luxury">Waist (cm)</Label>
                              <Input
                                id="waist"
                                type="number"
                                placeholder="e.g., 68"
                                value={customMeasurements.waist}
                                onChange={(e) =>
                                  setCustomMeasurements({ ...customMeasurements, waist: e.target.value })
                                }
                                className="input-luxury mt-2"
                              />
                            </div>
                            <div>
                              <Label htmlFor="length" className="label-luxury">Length (cm)</Label>
                              <Input
                                id="length"
                                type="number"
                                placeholder="e.g., 42"
                                value={customMeasurements.length}
                                onChange={(e) =>
                                  setCustomMeasurements({ ...customMeasurements, length: e.target.value })
                                }
                                className="input-luxury mt-2"
                              />
                            </div>
                          </div>
                        </div>
                      </TabsContent>
                    </Tabs>
                  </CardContent>
                </Card>

                {/* Quantity */}
                <div className="mb-8">
                  <Label className="label-luxury text-lg mb-4 block">Quantity</Label>
                  <div className="flex items-center gap-6">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="border-2 border-gold text-forest-green hover:bg-light-gold w-12 h-12 rounded-full"
                    >
                      <Minus className="w-5 h-5" />
                    </Button>
                    <span className="text-3xl font-serif font-bold text-forest-green w-12 text-center">
                      {quantity}
                    </span>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setQuantity(quantity + 1)}
                      className="border-2 border-gold text-forest-green hover:bg-light-gold w-12 h-12 rounded-full"
                    >
                      <Plus className="w-5 h-5" />
                    </Button>
                  </div>
                </div>

                {/* Add to Cart */}
                <Button
                  size="lg"
                  className="w-full btn-primary text-xl py-8"
                  onClick={handleAddToCart}
                >
                  <ShoppingCart className="w-6 h-6 mr-3" />
                  Add to Cart
                </Button>
              </motion.div>
            </div>

            {/* Comprehensive Details Tabs */}
            <div className="mb-24 scroll-mt-32" id="comprehensive-tabs">
              <Tabs value={bottomTab} onValueChange={setBottomTab} className="w-full">
                <TabsList className="grid w-full grid-cols-1 md:grid-cols-3 bg-light-gold border-2 border-gold h-auto p-1 rounded-xl">
                  <TabsTrigger value="size-chart" className="data-[state=active]:bg-gold data-[state=active]:text-cream py-4 text-xl font-serif rounded-lg transition-all">
                    Size Chart
                  </TabsTrigger>
                  <TabsTrigger value="style-colors" className="data-[state=active]:bg-gold data-[state=active]:text-cream py-4 text-xl font-serif rounded-lg transition-all">
                    Style, Colors & Care
                  </TabsTrigger>
                  <TabsTrigger value="custom-guide" className="data-[state=active]:bg-gold data-[state=active]:text-cream py-4 text-xl font-serif rounded-lg transition-all">
                    Custom Fit Guide
                  </TabsTrigger>
                </TabsList>
                
                <div className="mt-8 p-8 bg-white border-2 border-gold rounded-xl shadow-sm">
                  <TabsContent value="size-chart" className="mt-0">
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <SizeChartTable />
                    </motion.div>
                  </TabsContent>
                  
                  <TabsContent value="style-colors" className="mt-0">
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <StyleColorChart product={product} />
                    </motion.div>
                  </TabsContent>

                  <TabsContent value="custom-guide" className="mt-0">
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <CustomMeasurementGuide />
                    </motion.div>
                  </TabsContent>
                </div>
              </Tabs>
            </div>

            {/* Related Products */}
            {relatedProducts.length > 0 && (
              <div>
                <div className="text-center mb-12">
                  <h2 className="font-serif text-4xl font-bold text-forest-green mb-4">
                    You May Also Like
                  </h2>
                  <OrnateDivider />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                  {relatedProducts.map((relatedProduct) => (
                    <ProductCard key={relatedProduct.id} product={relatedProduct} />
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        <Footer />
      </div>
    </>
  );
};

export default ProductDetail;s