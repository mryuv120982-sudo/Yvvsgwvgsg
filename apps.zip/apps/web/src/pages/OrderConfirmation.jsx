import React, { useEffect, useState } from 'react';
import { useParams, useLocation, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { CheckCircle, Package, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import pb from '@/lib/pocketbaseClient';

const CornerOrnament = ({ className }) => (
  <svg className={`absolute w-8 h-8 text-gold ${className}`} viewBox="0 0 32 32" fill="currentColor">
    <path d="M0 0h32v2H2V32H0z"/>
    <path d="M6 6h16v2H8v16H6z"/>
  </svg>
);

const OrderConfirmation = () => {
  const { id } = useParams();
  const location = useLocation();
  const [order, setOrder] = useState(location.state?.order || null);

  useEffect(() => {
    if (!order) {
      const fetchOrder = async () => {
        try {
          const record = await pb.collection('orders').getOne(id, { $autoCancel: false });
          setOrder(record);
        } catch (error) {
          console.error('Error fetching order:', error);
        }
      };
      fetchOrder();
    }
  }, [id, order]);

  if (!order) {
    return (
      <>
        <Header />
        <div className="min-h-screen bg-cream flex items-center justify-center pt-20">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-gold border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-forest-green font-serif text-xl">Loading order details...</p>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  const estimatedDelivery = new Date();
  estimatedDelivery.setDate(estimatedDelivery.getDate() + 7);

  return (
    <>
      <Helmet>
        <title>Order Confirmed - Pehrin</title>
        <meta name="description" content="Your order has been successfully placed" />
      </Helmet>

      <div className="min-h-screen bg-cream">
        <Header />

        <div className="pt-32 pb-24 px-4">
          <div className="container mx-auto max-w-3xl">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="text-center mb-12"
            >
              <CheckCircle className="w-24 h-24 text-gold mx-auto mb-6" />
              <h1 className="font-serif text-5xl md:text-6xl font-bold text-forest-green mb-4">
                Order Confirmed!
              </h1>
              <p className="text-2xl text-rose-blush font-serif italic">
                Thank you for shopping with Pehrin
              </p>
            </motion.div>

            <Card className="border-2 border-gold bg-white shadow-gold mb-10 relative overflow-hidden">
              <CornerOrnament className="top-0 left-0" />
              <CornerOrnament className="bottom-0 right-0 rotate-180" />
              
              <CardHeader className="border-b border-gold/30 bg-light-gold pt-8 pb-6">
                <CardTitle className="font-serif text-3xl text-forest-green text-center">
                  Order Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-8 p-8">
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <p className="text-sm text-forest-green/70 font-bold uppercase tracking-wider mb-1">Order ID</p>
                    <p className="font-serif text-lg font-bold text-forest-green">{order.id}</p>
                  </div>
                  <div>
                    <p className="text-sm text-forest-green/70 font-bold uppercase tracking-wider mb-1">Order Date</p>
                    <p className="font-serif text-lg font-bold text-forest-green">
                      {new Date(order.created).toLocaleDateString('en-IN')}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-forest-green/70 font-bold uppercase tracking-wider mb-1">Payment Method</p>
                    <p className="font-serif text-lg font-bold text-forest-green capitalize">
                      {order.paymentMethod === 'cod' ? 'Cash on Delivery' : order.paymentMethod.toUpperCase()}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-forest-green/70 font-bold uppercase tracking-wider mb-1">Estimated Delivery</p>
                    <p className="font-serif text-lg font-bold text-forest-green">
                      {estimatedDelivery.toLocaleDateString('en-IN')}
                    </p>
                  </div>
                </div>

                <div className="h-[1px] w-full bg-gold/30"></div>

                <div>
                  <p className="text-sm text-forest-green/70 font-bold uppercase tracking-wider mb-3">Delivery Address</p>
                  <div className="bg-light-gold border border-gold/30 p-5 rounded-lg">
                    <p className="font-serif text-xl font-bold text-forest-green mb-1">{order.deliveryAddress.name}</p>
                    <p className="text-forest-green/80">{order.deliveryAddress.phone}</p>
                    <p className="text-forest-green/80 mt-2">{order.deliveryAddress.address}</p>
                    <p className="text-forest-green/80">
                      {order.deliveryAddress.city}, {order.deliveryAddress.state} - {order.deliveryAddress.pincode}
                    </p>
                  </div>
                </div>

                <div className="h-[1px] w-full bg-gold/30"></div>

                <div>
                  <p className="text-sm text-forest-green/70 font-bold uppercase tracking-wider mb-4">Order Items</p>
                  <div className="space-y-4">
                    {order.items.map((item, index) => (
                      <div key={index} className="flex justify-between items-start bg-light-gold border border-gold/30 p-4 rounded-lg">
                        <div className="flex-1">
                          <p className="font-serif text-xl font-bold text-forest-green mb-1">{item.name}</p>
                          <p className="text-sm text-forest-green/80">
                            {item.sizeType === 'standard' 
                              ? `Size: ${item.standardSize}` 
                              : `Custom: ${item.customMeasurements.bust}/${item.customMeasurements.waist}/${item.customMeasurements.length}cm`
                            }
                          </p>
                          <p className="text-sm text-forest-green/80 mt-1">Quantity: <span className="font-bold">{item.quantity}</span></p>
                        </div>
                        <p className="font-serif text-xl font-bold text-gold">
                          ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="h-[1px] w-full bg-gold/30"></div>

                <div className="flex justify-between text-3xl font-serif font-bold text-forest-green">
                  <span>Total Amount</span>
                  <span className="text-gold">₹{order.totalAmount.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</span>
                </div>
              </CardContent>
            </Card>

            <div className="flex flex-col sm:flex-row gap-6 justify-center">
              <Link to="/profile">
                <Button size="lg" className="btn-primary w-full sm:w-auto px-10 py-6 text-lg">
                  <Package className="w-5 h-5 mr-2" />
                  Track Order
                </Button>
              </Link>
              <Link to="/">
                <Button size="lg" className="btn-secondary w-full sm:w-auto px-10 py-6 text-lg">
                  <Home className="w-5 h-5 mr-2" />
                  Back to Home
                </Button>
              </Link>
            </div>
          </div>
        </div>

        <Footer />
      </div>
    </>
  );
};

export default OrderConfirmation;