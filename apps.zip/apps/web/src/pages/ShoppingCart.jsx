import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const ShoppingCart = () => {
  const [cartItems, setCartItems] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    loadCart();
    
    const handleCartUpdate = () => {
      loadCart();
    };
    
    window.addEventListener('cartUpdated', handleCartUpdate);
    return () => window.removeEventListener('cartUpdated', handleCartUpdate);
  }, []);

  const loadCart = () => {
    const cart = JSON.parse(localStorage.getItem('pehrin_cart') || '[]');
    setCartItems(cart);
  };

  const updateQuantity = (index, newQuantity) => {
    if (newQuantity < 1) return;
    
    const updatedCart = [...cartItems];
    updatedCart[index].quantity = newQuantity;
    localStorage.setItem('pehrin_cart', JSON.stringify(updatedCart));
    setCartItems(updatedCart);
    window.dispatchEvent(new Event('cartUpdated'));
  };

  const removeItem = (index) => {
    const updatedCart = cartItems.filter((_, i) => i !== index);
    localStorage.setItem('pehrin_cart', JSON.stringify(updatedCart));
    setCartItems(updatedCart);
    window.dispatchEvent(new Event('cartUpdated'));
  };

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const tax = subtotal * 0.18; // 18% GST
  const total = subtotal + tax;

  const imageUrl = (item) => 
    `https://via.placeholder.com/200x250/F5F1E8/2D5016?text=${encodeURIComponent(item.name)}`;

  if (cartItems.length === 0) {
    return (
      <>
        <Helmet>
          <title>Shopping Cart - Pehrin</title>
          <meta name="description" content="View and manage your shopping cart items" />
        </Helmet>

        <div className="min-h-screen bg-cream">
          <Header />
          
          <div className="pt-32 pb-24 px-4">
            <div className="container mx-auto max-w-4xl text-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="bg-white border-2 border-gold border-dashed rounded-xl p-16"
              >
                <ShoppingBag className="w-24 h-24 text-gold mx-auto mb-8" />
                <h1 className="font-serif text-5xl font-bold text-forest-green mb-6">
                  Your Cart is Empty
                </h1>
                <p className="text-xl text-forest-green/70 mb-10 font-serif italic">
                  Looks like you haven't added anything to your cart yet
                </p>
                <Link to="/shop">
                  <Button size="lg" className="btn-primary px-12 py-6 text-lg">
                    Continue Shopping
                  </Button>
                </Link>
              </motion.div>
            </div>
          </div>

          <Footer />
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>Shopping Cart - Pehrin</title>
        <meta name="description" content="Review your cart items and proceed to checkout" />
      </Helmet>

      <div className="min-h-screen bg-cream">
        <Header />

        <div className="pt-32 pb-24 px-4">
          <div className="container mx-auto max-w-6xl">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="font-serif text-5xl md:text-6xl font-bold text-forest-green mb-12 text-center"
            >
              Shopping Cart
            </motion.h1>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
              {/* Cart Items */}
              <div className="lg:col-span-2 space-y-6">
                {cartItems.map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                  >
                    <Card className="border-2 border-gold bg-white shadow-sm hover:shadow-gold transition-shadow duration-300">
                      <CardContent className="p-6">
                        <div className="flex flex-col sm:flex-row gap-6">
                          <div className="border border-gold p-1 bg-light-gold flex-shrink-0">
                            <img
                              src={imageUrl(item)}
                              alt={item.name}
                              className="w-32 h-40 object-cover"
                            />
                          </div>
                          
                          <div className="flex-1 flex flex-col justify-between">
                            <div>
                              <h3 className="font-serif text-2xl font-bold text-forest-green mb-2">
                                {item.name}
                              </h3>
                              
                              <div className="text-forest-green/80 mb-4 font-sans bg-light-gold p-3 rounded border border-gold/30">
                                {item.sizeType === 'standard' ? (
                                  <p><span className="font-bold">Size:</span> {item.standardSize}</p>
                                ) : (
                                  <div>
                                    <p className="font-bold mb-1 text-gold-dark">Custom Fit:</p>
                                    <p>Bust: {item.customMeasurements.bust}cm | Waist: {item.customMeasurements.waist}cm | Length: {item.customMeasurements.length}cm</p>
                                  </div>
                                )}
                                {item.color && <p className="mt-1"><span className="font-bold">Color:</span> {item.color}</p>}
                              </div>
                            </div>

                            <div className="flex items-center justify-between mt-4">
                              <p className="text-3xl font-serif font-bold text-gold">
                                ₹{item.price.toLocaleString('en-IN')}
                              </p>

                              <div className="flex items-center gap-6">
                                <div className="flex items-center gap-3 bg-cream border border-gold rounded-full p-1">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => updateQuantity(index, item.quantity - 1)}
                                    className="h-8 w-8 rounded-full text-forest-green hover:bg-gold hover:text-cream"
                                  >
                                    <Minus className="w-4 h-4" />
                                  </Button>
                                  <span className="text-lg font-bold w-6 text-center text-forest-green">
                                    {item.quantity}
                                  </span>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => updateQuantity(index, item.quantity + 1)}
                                    className="h-8 w-8 rounded-full text-forest-green hover:bg-gold hover:text-cream"
                                  >
                                    <Plus className="w-4 h-4" />
                                  </Button>
                                </div>

                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => removeItem(index)}
                                  className="text-rose-blush hover:text-white hover:bg-rose-blush rounded-full transition-colors"
                                >
                                  <Trash2 className="w-5 h-5" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>

              {/* Order Summary */}
              <div className="lg:col-span-1">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  <Card className="border-2 border-gold bg-white sticky top-32 shadow-gold">
                    <CardContent className="p-8">
                      <h2 className="font-serif text-3xl font-bold text-forest-green mb-6 text-center">
                        Order Summary
                      </h2>
                      
                      <div className="h-[1px] w-full bg-gold/30 mb-6"></div>

                      <div className="space-y-4 mb-6 text-lg">
                        <div className="flex justify-between text-forest-green/80">
                          <span>Subtotal</span>
                          <span className="font-bold">₹{subtotal.toLocaleString('en-IN')}</span>
                        </div>
                        <div className="flex justify-between text-forest-green/80">
                          <span>Tax (GST 18%)</span>
                          <span className="font-bold">₹{tax.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</span>
                        </div>
                      </div>

                      <div className="h-[1px] w-full bg-gold/30 mb-6"></div>

                      <div className="flex justify-between text-2xl font-serif font-bold text-forest-green mb-8">
                        <span>Total</span>
                        <span className="text-gold">₹{total.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</span>
                      </div>

                      <Button
                        size="lg"
                        className="w-full btn-primary py-6 text-lg mb-4"
                        onClick={() => navigate('/checkout')}
                      >
                        Proceed to Checkout
                        <ArrowRight className="w-5 h-5 ml-2" />
                      </Button>

                      <Link to="/shop">
                        <Button variant="outline" size="lg" className="w-full btn-secondary py-6 text-lg">
                          Continue Shopping
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            </div>
          </div>
        </div>

        <Footer />
      </div>
    </>
  );
};

export default ShoppingCart;