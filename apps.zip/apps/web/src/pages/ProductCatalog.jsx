import React, { useEffect, useState, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { SearchX, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ProductCard from '@/components/ProductCard.jsx';
import SearchBar from '@/components/SearchBar.jsx';
import FilterBar from '@/components/FilterBar.jsx';
import pb from '@/lib/pocketbaseClient';

const OrnateDivider = () => (
  <div className="flex items-center justify-center gap-4 my-8">
    <div className="h-[1px] w-24 bg-gradient-to-r from-transparent to-primary"></div>
    <div className="w-2 h-2 rotate-45 bg-primary"></div>
    <div className="h-[1px] w-24 bg-gradient-to-l from-transparent to-primary"></div>
  </div>
);

const ProductCatalog = () => {
  const [products, setProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Filters & Pagination State
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('newest');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [categoryCounts, setCategoryCounts] = useState({ all: 0, kurti: 0, jeans: 0 });
  
  const itemsPerPage = 12;

  // Fetch category counts once
  useEffect(() => {
    const fetchCounts = async () => {
      try {
        const allRes = await pb.collection('products').getList(1, 1, { $autoCancel: false });
        const kurtiRes = await pb.collection('products').getList(1, 1, { filter: 'category="kurti"', $autoCancel: false });
        const jeansRes = await pb.collection('products').getList(1, 1, { filter: 'category="jeans"', $autoCancel: false });
        
        setCategoryCounts({
          all: allRes.totalItems,
          kurti: kurtiRes.totalItems,
          jeans: jeansRes.totalItems
        });
      } catch (error) {
        console.error('Error fetching counts:', error);
      }
    };
    fetchCounts();
  }, []);

  // Fetch products based on filters
  const fetchProducts = useCallback(async () => {
    setIsLoading(true);
    try {
      let filterStr = '';
      const filters = [];

      if (selectedCategory !== 'all') {
        filters.push(`category = "${selectedCategory}"`);
      }

      if (searchQuery) {
        // PocketBase uses ~ for LIKE queries
        filters.push(`(name ~ "${searchQuery}" || description ~ "${searchQuery}")`);
      }

      if (filters.length > 0) {
        filterStr = filters.join(' && ');
      }

      let sortStr = '-created';
      switch (sortBy) {
        case 'price-low': sortStr = 'price'; break;
        case 'price-high': sortStr = '-price'; break;
        case 'newest': sortStr = '-created'; break;
        case 'rating': sortStr = '-rating'; break;
        default: sortStr = '-created';
      }

      const result = await pb.collection('products').getList(page, itemsPerPage, {
        filter: filterStr,
        sort: sortStr,
        $autoCancel: false,
      });

      setProducts(result.items);
      setTotalPages(result.totalPages);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setIsLoading(false);
    }
  }, [selectedCategory, searchQuery, sortBy, page]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  // Reset page to 1 when filters change
  useEffect(() => {
    setPage(1);
  }, [selectedCategory, searchQuery, sortBy]);

  return (
    <>
      <Helmet>
        <title>Shop - Pehrin</title>
        <meta name="description" content="Browse our complete collection of kurtis and jeans. Find your perfect style with custom fits and celebrity-inspired designs." />
      </Helmet>

      <div className="min-h-screen bg-background relative">
        {/* Subtle Background Pattern */}
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMiIgY3k9IjIiIHI9IjEiIGZpbGw9IiNEMEFGMzciLz48L3N2Zz4=')]"></div>
        
        <Header />

        <div className="pt-32 pb-24 px-4 relative z-10">
          <div className="container mx-auto max-w-7xl">
            
            {/* Header Section */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center mb-12"
            >
              <h1 className="font-serif text-5xl md:text-6xl font-bold text-foreground mb-4">
                Shop Our Collection
              </h1>
              <OrnateDivider />
              <p className="text-xl text-foreground/80 max-w-2xl mx-auto font-serif italic">
                Discover trending styles and custom-fit fashion tailored just for you.
              </p>
            </motion.div>

            {/* Search & Filter Section */}
            <div className="mb-16 space-y-8">
              <SearchBar 
                searchTerm={searchQuery} 
                onSearchChange={setSearchQuery} 
              />
              <FilterBar 
                selectedCategory={selectedCategory}
                onCategoryChange={setSelectedCategory}
                sortBy={sortBy}
                onSortChange={setSortBy}
                categoryCounts={categoryCounts}
              />
            </div>

            {/* Products Grid */}
            {isLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="bg-background rounded-xl p-5 animate-pulse border border-primary/20">
                    <div className="aspect-square bg-primary/10 rounded-md mb-5"></div>
                    <div className="h-6 bg-primary/10 rounded mb-3 w-3/4"></div>
                    <div className="h-4 bg-primary/10 rounded mb-4 w-1/2"></div>
                    <div className="h-8 bg-primary/10 rounded w-1/3 mb-5"></div>
                    <div className="h-12 bg-primary/10 rounded w-full"></div>
                  </div>
                ))}
              </div>
            ) : products.length > 0 ? (
              <>
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.5 }}
                  className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8"
                >
                  {products.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </motion.div>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="mt-16 flex items-center justify-center gap-2">
                    <Button
                      variant="outline"
                      onClick={() => setPage(p => Math.max(1, p - 1))}
                      disabled={page === 1}
                      className="border-primary text-foreground hover:bg-primary/10"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </Button>
                    
                    <div className="flex items-center gap-2 mx-4">
                      {[...Array(totalPages)].map((_, i) => {
                        const pageNum = i + 1;
                        return (
                          <button
                            key={pageNum}
                            onClick={() => setPage(pageNum)}
                            className={`w-10 h-10 rounded-full font-serif font-bold transition-all ${
                              page === pageNum
                                ? 'bg-primary text-primary-foreground shadow-md'
                                : 'bg-transparent border border-primary text-foreground hover:bg-primary/10'
                            }`}
                          >
                            {pageNum}
                          </button>
                        );
                      })}
                    </div>

                    <Button
                      variant="outline"
                      onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                      disabled={page === totalPages}
                      className="border-primary text-foreground hover:bg-primary/10"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </Button>
                  </div>
                )}
              </>
            ) : (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-24 bg-background border border-primary/30 border-dashed rounded-2xl shadow-sm max-w-3xl mx-auto"
              >
                <div className="bg-primary/10 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6">
                  <SearchX className="w-12 h-12 text-primary" />
                </div>
                <h3 className="text-3xl text-foreground font-serif font-bold mb-3">No products found</h3>
                <p className="text-foreground/70 text-lg mb-8 font-sans">
                  We couldn't find any products matching your current filters. Try adjusting your search or category.
                </p>
                <Button 
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('all');
                  }}
                  className="btn-secondary px-8 py-6"
                >
                  Clear All Filters
                </Button>
              </motion.div>
            )}
          </div>
        </div>

        <Footer />
      </div>
    </>
  );
};

export default ProductCatalog;