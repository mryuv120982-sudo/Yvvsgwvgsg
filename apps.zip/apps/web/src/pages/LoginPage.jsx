import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Mail, Lock, LogIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { useToast } from '@/hooks/use-toast';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!email || !password) {
      toast({
        title: 'Missing Information',
        description: 'Please fill in all fields',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    const result = await login(email, password);
    setIsLoading(false);

    if (result.success) {
      toast({
        title: 'Welcome back!',
        description: 'You have successfully logged in.',
      });
      navigate('/');
    } else {
      toast({
        title: 'Login Failed',
        description: result.error || 'Invalid email or password',
        variant: 'destructive',
      });
    }
  };

  return (
    <>
      <Helmet>
        <title>Login - Pehrin</title>
        <meta name="description" content="Login to your Pehrin account to access exclusive fashion collections and manage your orders." />
      </Helmet>

      <div className="min-h-screen bg-cream">
        <Header />
        
        <div className="pt-32 pb-24 px-4">
          <div className="container mx-auto max-w-md">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Card className="border-2 border-gold bg-white shadow-gold relative overflow-hidden">
                {/* Decorative Top Border */}
                <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-gold-dark via-gold to-gold-dark"></div>
                
                <CardHeader className="text-center pt-10 pb-6">
                  <CardTitle className="font-serif text-4xl font-bold text-forest-green mb-2">Welcome Back</CardTitle>
                  <CardDescription className="text-forest-green/70 font-serif italic text-lg">Login to your Pehrin account</CardDescription>
                </CardHeader>
                
                <CardContent className="px-8">
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="space-y-3">
                      <Label htmlFor="email" className="label-luxury">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-4 top-3.5 w-5 h-5 text-gold" />
                        <Input
                          id="email"
                          type="email"
                          placeholder="your@email.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="input-luxury pl-12 py-6"
                          disabled={isLoading}
                        />
                      </div>
                    </div>

                    <div className="space-y-3">
                      <Label htmlFor="password" className="label-luxury">Password</Label>
                      <div className="relative">
                        <Lock className="absolute left-4 top-3.5 w-5 h-5 text-gold" />
                        <Input
                          id="password"
                          type="password"
                          placeholder="••••••••"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="input-luxury pl-12 py-6"
                          disabled={isLoading}
                        />
                      </div>
                    </div>

                    <Button
                      type="submit"
                      className="w-full btn-primary py-6 text-lg mt-4"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        'Logging in...'
                      ) : (
                        <>
                          <LogIn className="w-5 h-5 mr-2" />
                          Login
                        </>
                      )}
                    </Button>
                  </form>
                </CardContent>

                <CardFooter className="flex flex-col gap-4 pb-8 pt-4">
                  <div className="h-[1px] w-full bg-gold/30 mb-2"></div>
                  <div className="text-center text-forest-green/80 font-sans">
                    Don't have an account?{' '}
                    <Link to="/signup" className="text-gold hover:text-gold-dark font-bold hover:underline transition-all">
                      Sign up
                    </Link>
                  </div>
                </CardFooter>
              </Card>
            </motion.div>
          </div>
        </div>

        <Footer />
      </div>
    </>
  );
};

export default LoginPage;