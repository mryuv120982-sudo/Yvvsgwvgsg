import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { CreditCard, Smartphone, Banknote } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext.jsx';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import pb from '@/lib/pocketbaseClient';

const CheckoutPage = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { currentUser, isAuthenticated } = useAuth();
  const [cartItems, setCartItems] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('cod');
  const [deliveryAddress, setDeliveryAddress] = useState({
    name: currentUser?.name || '',
    phone: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
  });

  useEffect(() => {
    if (!isAuthenticated) {
      toast({
        title: 'Login Required',
        description: 'Please login to proceed with checkout',
        variant: 'destructive',
      });
      navigate('/login');
      return;
    }

    const cart = JSON.parse(localStorage.getItem('pehrin_cart') || '[]');
    if (cart.length === 0) {
      navigate('/cart');
      return;
    }
    setCartItems(cart);
  }, [isAuthenticated, navigate, toast, currentUser]);

  const handleInputChange = (e) => {
    setDeliveryAddress({
      ...deliveryAddress,
      [e.target.name]: e.target.value,
    });
  };

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const tax = subtotal * 0.18;
  const total = subtotal + tax;

  const handlePlaceOrder = async (e) => {
    e.preventDefault();

    if (!deliveryAddress.name || !deliveryAddress.phone || !deliveryAddress.address || 
        !deliveryAddress.city || !deliveryAddress.state || !deliveryAddress.pincode) {
      toast({
        title: 'Incomplete Address',
        description: 'Please fill in all delivery address fields',
        variant: 'destructive',
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const orderData = {
        userId: currentUser.id,
        items: cartItems,
        totalAmount: total,
        deliveryAddress,
        paymentMethod,
        orderStatus: 'pending',
      };

      const order = await pb.collection('orders').create(orderData, { $autoCancel: false });

      localStorage.removeItem('pehrin_cart');
      window.dispatchEvent(new Event('cartUpdated'));

      navigate(`/order-confirmation/${order.id}`, { state: { order } });
    } catch (error) {
      console.error('Order creation error:', error);
      toast({
        title: 'Order Failed',
        description: error.message || 'Failed to place order. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const paymentMethods = [
    { id: 'cod', name: 'Cash on Delivery', icon: Banknote },
    { id: 'upi', name: 'UPI', icon: Smartphone },
    { id: 'card', name: 'Credit/Debit Card', icon: CreditCard },
  ];

  return (
    <>
      <Helmet>
        <title>Checkout - Pehrin</title>
        <meta name="description" content="Complete your order and enter delivery details" />
      </Helmet>

      <div className="min-h-screen bg-cream">
        <Header />

        <div className="pt-32 pb-24 px-4">
          <div className="container mx-auto max-w-6xl">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="font-serif text-5xl md:text-6xl font-bold text-forest-green mb-12 text-center"
            >
              Checkout
            </motion.h1>

            <form onSubmit={handlePlaceOrder}>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
                {/* Delivery Address & Payment */}
                <div className="lg:col-span-2 space-y-8">
                  {/* Delivery Address */}
                  <Card className="border-2 border-gold bg-white shadow-sm">
                    <CardHeader className="border-b border-gold/30 bg-light-gold">
                      <CardTitle className="font-serif text-3xl text-forest-green">
                        Delivery Address
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6 p-8">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <Label htmlFor="name" className="label-luxury">Full Name</Label>
                          <Input
                            id="name"
                            name="name"
                            value={deliveryAddress.name}
                            onChange={handleInputChange}
                            className="input-luxury mt-2"
                            required
                          />
                        </div>
                        <div>
                          <Label htmlFor="phone" className="label-luxury">Phone Number</Label>
                          <Input
                            id="phone"
                            name="phone"
                            type="tel"
                            value={deliveryAddress.phone}
                            onChange={handleInputChange}
                            className="input-luxury mt-2"
                            required
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="address" className="label-luxury">Street Address</Label>
                        <Input
                          id="address"
                          name="address"
                          value={deliveryAddress.address}
                          onChange={handleInputChange}
                          className="input-luxury mt-2"
                          required
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div>
                          <Label htmlFor="city" className="label-luxury">City</Label>
                          <Input
                            id="city"
                            name="city"
                            value={deliveryAddress.city}
                            onChange={handleInputChange}
                            className="input-luxury mt-2"
                            required
                          />
                        </div>
                        <div>
                          <Label htmlFor="state" className="label-luxury">State</Label>
                          <Input
                            id="state"
                            name="state"
                            value={deliveryAddress.state}
                            onChange={handleInputChange}
                            className="input-luxury mt-2"
                            required
                          />
                        </div>
                        <div>
                          <Label htmlFor="pincode" className="label-luxury">Pincode</Label>
                          <Input
                            id="pincode"
                            name="pincode"
                            value={deliveryAddress.pincode}
                            onChange={handleInputChange}
                            className="input-luxury mt-2"
                            required
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Payment Method */}
                  <Card className="border-2 border-gold bg-white shadow-sm">
                    <CardHeader className="border-b border-gold/30 bg-light-gold">
                      <CardTitle className="font-serif text-3xl text-forest-green">
                        Payment Method
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-8">
                      <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="space-y-4">
                        {paymentMethods.map((method) => (
                          <div key={method.id} className={`flex items-center space-x-4 p-5 border-2 rounded-lg transition-all duration-300 cursor-pointer ${paymentMethod === method.id ? 'border-gold bg-light-gold shadow-sm' : 'border-gold/30 hover:border-gold/60'}`}>
                            <RadioGroupItem value={method.id} id={method.id} className="text-gold border-gold" />
                            <Label htmlFor={method.id} className="flex items-center gap-4 cursor-pointer flex-1 text-lg font-serif font-bold text-forest-green">
                              <method.icon className="w-6 h-6 text-gold" />
                              {method.name}
                            </Label>
                          </div>
                        ))}
                      </RadioGroup>
                    </CardContent>
                  </Card>
                </div>

                {/* Order Summary */}
                <div className="lg:col-span-1">
                  <Card className="border-2 border-gold bg-white sticky top-32 shadow-gold">
                    <CardHeader className="border-b border-gold/30 bg-light-gold">
                      <CardTitle className="font-serif text-3xl text-forest-green text-center">
                        Order Summary
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-8">
                      <div className="space-y-4 mb-6">
                        {cartItems.map((item, index) => (
                          <div key={index} className="flex justify-between text-base border-b border-gold/10 pb-3 last:border-0">
                            <span className="text-forest-green/80 font-medium">
                              {item.name} <span className="text-gold-dark">x {item.quantity}</span>
                            </span>
                            <span className="text-forest-green font-bold">
                              ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                            </span>
                          </div>
                        ))}
                      </div>

                      <div className="h-[1px] w-full bg-gold/30 my-6"></div>

                      <div className="space-y-3 mb-6 text-lg">
                        <div className="flex justify-between text-forest-green/80">
                          <span>Subtotal</span>
                          <span className="font-bold">₹{subtotal.toLocaleString('en-IN')}</span>
                        </div>
                        <div className="flex justify-between text-forest-green/80">
                          <span>Tax (GST 18%)</span>
                          <span className="font-bold">₹{tax.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</span>
                        </div>
                      </div>

                      <div className="h-[1px] w-full bg-gold/30 my-6"></div>

                      <div className="flex justify-between text-2xl font-serif font-bold text-forest-green mb-8">
                        <span>Total</span>
                        <span className="text-gold">₹{total.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</span>
                      </div>

                      <Button
                        type="submit"
                        size="lg"
                        className="w-full btn-primary py-6 text-lg"
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? 'Placing Order...' : 'Place Order'}
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </form>
          </div>
        </div>

        <Footer />
      </div>
    </>
  );
};

export default CheckoutPage;